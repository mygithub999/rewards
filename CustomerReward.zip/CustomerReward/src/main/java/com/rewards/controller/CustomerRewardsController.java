package com.rewards.controller;


import com.rewards.model.Order;
import com.rewards.service.CustomerRewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
public class CustomerRewardsController {

	private CustomerRewardsService customerRewardsService;
	@Autowired
	public CustomerRewardsController(CustomerRewardsService customerRewardsService){
		this.customerRewardsService = customerRewardsService;
	}
	@PostMapping(path = "/order", produces = MediaType.APPLICATION_JSON_VALUE)
	public String createCustomerOrder (@RequestBody Order order) {
		 this.customerRewardsService.createCustomerOrder(order);
		 return "Success";
		
	}

}
