package com.rewards.repository.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "CUSTOMER_ORDER_TRANSACTIONS")
public class CustomerOrderTransactionEntity {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long transactionId;

    @ManyToOne(cascade = CascadeType.ALL)
    private CustomerEntity customer;

    private Date transactionDate;

    private Double price;

    private long rewardPoints;

}


