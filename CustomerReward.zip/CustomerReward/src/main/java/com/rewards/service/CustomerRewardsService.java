package com.rewards.service;

import com.rewards.model.Items;
import com.rewards.model.Order;
import com.rewards.repository.CustomerOrderRepository;
import com.rewards.repository.CustomerRepository;
import com.rewards.repository.entity.CustomerEntity;
import com.rewards.repository.entity.CustomerOrderTransactionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.stream.Collectors;

@Service
public class CustomerRewardsService {

    private CustomerOrderRepository customerOrderRepository;
    private  CustomerRepository customerRepository;

    @Autowired
    public CustomerRewardsService(CustomerOrderRepository customerOrderRepository, CustomerRepository customerRepository){
    this.customerOrderRepository = customerOrderRepository;
    this.customerRepository = customerRepository;
    }

    public void createCustomerOrder(Order order){
        CustomerEntity customerEntity = customerRepository.findByNameAndTelephoneNo(order.getCustomer().getName(),order.getCustomer().getTelephoneNumber());
        if(customerEntity == null) {
            customerEntity = new CustomerEntity();
            customerEntity.setName(order.getCustomer().getName());
            customerEntity.setTelephoneNo(order.getCustomer().getTelephoneNumber());
        }
        CustomerOrderTransactionEntity customerOrderTransaction = new CustomerOrderTransactionEntity();
        customerOrderTransaction.setTransactionDate(new Date());
        customerOrderTransaction.setCustomer(customerEntity);
        customerOrderTransaction.setRewardPoints(calculateRewardPoints(order));
        this.customerOrderRepository.save(customerOrderTransaction);

    }

    private  int calculateRewardPoints(Order order){
        double price = order.getItems().stream().collect(Collectors.summarizingDouble(Items::getItemPrice)).getSum();
        int rewards = 0;
        if(price >= 100){
            rewards = ((int)price -100)*2;
            rewards = rewards + 50;
        }
        else if(rewards >= 50){
            rewards = 50;
        }
        return rewards;


    }

    public void getRewardPoints(String customerId,Date date){
        //this.customerOrderRepository.getReferenceById(customerId)
    }
}
