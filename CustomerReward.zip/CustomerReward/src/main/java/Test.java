import com.rewards.model.Items;
import com.rewards.model.Order;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
    /*public static void main(String[] args) {

        Order order = new Order();
        Items it = new Items();
        it.setItemName("test");
        it.setItemPrice(120);
        Items it1 = new Items();
        it1.setItemName("test1");
        it1.setItemPrice(140);
        List oi = new ArrayList<Items>();
        oi.add(it);
        oi.add(it1);
        order.setItems(oi);
        System.out.println(order.getItems().stream().collect(Collectors.summarizingDouble(Items::getItemPrice)));

    }*/
}
